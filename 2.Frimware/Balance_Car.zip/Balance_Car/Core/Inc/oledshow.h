/*
 * oledshow.h
 *
 *  Created on: Dec 5, 2022
 *      Author: HP
 */

#ifndef INC_OLEDSHOW_H_
#define INC_OLEDSHOW_H_

void Show_Encoder(void);	//编码器电机相关信息显示函数
void OLED_Show(void);	//OLED显示函数

#endif /* INC_OLEDSHOW_H_ */
