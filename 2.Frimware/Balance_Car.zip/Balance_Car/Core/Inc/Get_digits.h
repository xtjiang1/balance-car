/*
 * Get_digits.h
 *
 *  Created on: 2022年12月1日
 *      Author: HP
 */

#ifndef INC_GET_DIGITS_H_
#define INC_GET_DIGITS_H_

int Get_digits(float Input, float Digits);	//将浮点数类型的数据取小数点后几位

#endif /* INC_GET_DIGITS_H_ */
