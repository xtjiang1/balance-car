/*
 * Data_to_Matlab.c.h
 *
 *  Created on: 2023年1月12日
 *      Author: HP
 */

#ifndef INC_DATA_TO_MATLAB_H_
#define INC_DATA_TO_MATLAB_H_

void Dec_To_Hex(float Input);

#endif /* INC_DATA_TO_MATLAB_H_ */
