/*
 * jy61.h
 *
 *  Created on: 2022年12月24日
 *      Author: HP
 */

#ifndef INC_JY61_H_
#define INC_JY61_H_

void Jy61_RXData(void);		//jy61接收数据

#endif /* INC_JY61_H_ */
