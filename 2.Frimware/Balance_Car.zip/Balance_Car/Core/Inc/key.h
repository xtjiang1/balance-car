/*
 * key.h
 *
 *  Created on: Jan 28, 2023
 *      Author: jxt
 */

#ifndef INC_KEY_H_
#define INC_KEY_H_

void Key_Scan(void);

#endif /* INC_KEY_H_ */
